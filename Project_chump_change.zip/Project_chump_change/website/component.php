<?php

function component($productname, $productprice, $productimg, $productid){
    $element = "
    
                                        <div class=\"col-xl-4 col-md-6 col-lg-6 col-sm-6\">
                                            <form action=\"shop-grid-fw.php\" method=\"post\">
                                                                            <div class=\"product-wrap mb-25 scroll-zoom\">
                                                                                <div class=\"product-img\">
                                                                                    <a href=\"product-details.html\">
                                                                                        <img class=\"default-img\" src=\"$productimg\" alt=\"\">
                                                                                        <img class=\"hover-img\" src=\"$productimg\" alt=\"\">
                                                                                    </a>
                                                                                    <span class=\"pink\">-10%</span>
                                                                                    <div class=\"product-action\">
                                                                                        <div class=\"pro-same-action pro-wishlist\">
                                                                                            <a title=\"Wishlist\" href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                                                                        </div>
                                                                                        <div class=\"pro-same-action pro-cart\">
                                                                                                                        <button type=\"submit\" class=\"btn btn-dark my-3\" name=\"add\">Add to Cart </i></button>
                                                                                        <input type='hidden' name='product_id' value='$productid'>
                                                                                        </div>
                                                                                        <div class=\"pro-same-action pro-quickview\">
                                                                                            <a title=\"Quick View\" href=\"#\" data-bs-toggle=\"modal\" data-bs-target=\"#exampleModal\"><i class=\"pe-7s-look\"></i></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class=\"product-content text-center\">
                                                                                    <h3><a href=\"product-details.html\">>$productname</a></h3>
                                                                                 
                                                                                    <div class=\"product-price\">
                                                                                        <span>$$productprice</span>
                                                                                        <span class=\"old\">$$productprice</span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                                </div>
    ";
    echo $element;
}

function cartElement($productimg, $productname, $productprice, $productid){
    $element = "
    
    <form action=\"cart-page.php?action=remove&id=$productid\" method=\"post\" class=\"cart-items\">
                                    <tr>
                                                                     
                                                                        <td class=\"product-name\"><a href=\"#\">$productname</a></td>
                                                                        <td class=\"product-price-cart\"><span class=\"amount\">$productprice</span></td>
                                                                        <td class=\"product-quantity\">
                                                                            <div class=\"cart-plus-minus\">
                                                                                <input class=\"cart-plus-minus-box\" type=\"text\" name=\"qtybutton\" value=\"1\">
                                                                            </div>
                                                                        </td>
                                                                        <td class=\"product-subtotal\">$productprice</td>
                                                                        <td class=\"product-remove\">
                                                                            
                                                                                                            <button type=\"submit\" class=\"btn btn-danger mx-2\" name=\"remove\">Remove</button>
                                                                       </td>
                                                                    </tr>
                                                                    
                </form>
    
    ";
    echo  $element;
}

















