<?php

return [
    'mail' => [
        'to_email' => 'deepak_kasi_nathan@yahoo.com'
    ]
];
?>