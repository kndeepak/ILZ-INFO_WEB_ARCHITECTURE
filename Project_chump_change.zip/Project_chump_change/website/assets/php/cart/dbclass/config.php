<?php

//----------------------------------------
//Database set up

$dbhost 	= "localhost";							//usually localhost
$dbusername = "root";					//database user name
$dbpass 	= "root";					//database password
$dbname		= "project";						//database name

//----------------------------------------
?>