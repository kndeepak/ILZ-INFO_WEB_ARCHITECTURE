    <div class="footer">
		<div style="float:left;">
			<p>&copy; Company Name&nbsp;<?php echo( date ("Y")); ?></p>        		
		</div>
		<div style="float:right;">
			<a href="#"><i class="fa fa-twitter-square fa-2x" aria-hidden="true"></i></a>
			<a href="#"><i class="fa fa-facebook-square fa-2x" aria-hidden="true"></i></a>
			<a href="#"><i class="fa fa-linkedin-square fa-2x" aria-hidden="true"></i></a>
		</div>
	</div>