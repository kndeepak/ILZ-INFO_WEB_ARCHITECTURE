Date:    01-05-2022


Corrections by professor 
======================
1. I have updated maps to work with PHP, I bought a google developer account and updated maps with API key for google maps javascript API

2. I have made contact emails to come to my database as you suggested.



New Features added after the presentation :
============================================

1. Added an option to add products and delete them from the website itself with the register and login function 
2. Added provision to change personal details in the database
3.added tax calculation at cart option 
4. Minor tweaks and changes to remove redundant things from the website 



From 
Deepak Kasi Nathan (author) 
